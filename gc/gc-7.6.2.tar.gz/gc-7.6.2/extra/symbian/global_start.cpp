// Symbian-specific file.

// INCLUDE FILES
#include "private/gcconfig.h"

#ifdef __cplusplus
extern "C" {
#endif

int winscw_data_start;

#ifdef __cplusplus
        }
#endif

// End Of File
